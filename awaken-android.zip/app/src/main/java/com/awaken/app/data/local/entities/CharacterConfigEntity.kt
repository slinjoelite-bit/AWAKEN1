package com.awaken.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "character_configs")
data class CharacterConfigEntity(
    @PrimaryKey val id: String,
    val name: String,
    val title: String,
    val dialoguesJson: String,
    val entranceAnimation: String,
    val customImageUri: String? = null,
    val customAudioUri: String? = null,
    val tonePitch: Float = 160f,
    val enabled: Boolean = true
)
