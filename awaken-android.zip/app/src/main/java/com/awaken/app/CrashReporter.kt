package com.awaken.app

import android.content.Context
import android.content.Intent
import android.os.Process
import android.util.Log
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Catches any crash, shows the full error on screen (so it can be screenshotted)
 * and then closes the app. Does not change normal app behaviour.
 */
object CrashReporter {
    fun install(context: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val trace = sw.toString().take(9000)
                Log.e("AWAKEN_CRASH", trace)
                val intent = Intent(context, CrashActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    putExtra("trace", "Thread: ${thread.name}\n\n$trace")
                }
                context.startActivity(intent)
                Thread.sleep(600)
            } catch (e: Throwable) {
                previous?.uncaughtException(thread, throwable)
            } finally {
                Process.killProcess(Process.myPid())
                System.exit(10)
            }
        }
    }
}
