package com.awaken.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "question_responses")
data class QuestionResponseEntity(
    @PrimaryKey val id: String,
    val questionId: String,
    val prompt: String,
    val selectedAnswer: String,
    val timestamp: String,
    val reelCountAtTime: Int
)
