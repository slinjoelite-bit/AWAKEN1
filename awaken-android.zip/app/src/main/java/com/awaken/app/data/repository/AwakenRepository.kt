package com.awaken.app.data.repository

import android.content.Context
import android.content.Intent
import com.awaken.app.data.local.AwakenDatabase
import com.awaken.app.data.local.entities.DailyStatsEntity
import com.awaken.app.services.CharacterPopupService
import com.awaken.app.services.RedWarningService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AwakenRepository(
    private val database: AwakenDatabase,
    private val context: Context
) {
    private val statsDao = database.dailyStatsDao()
    private val repoScope = CoroutineScope(Dispatchers.IO)

    private val _currentDayReelsFlow = MutableStateFlow(0)
    val currentDayReelsFlow: StateFlow<Int> = _currentDayReelsFlow.asStateFlow()

    private val _dailyGoalFlow = MutableStateFlow(50)
    val dailyGoalFlow: StateFlow<Int> = _dailyGoalFlow.asStateFlow()

    private val _isFeedActiveFlow = MutableStateFlow(false)
    val isFeedActiveFlow: StateFlow<Boolean> = _isFeedActiveFlow.asStateFlow()

    // Configurable milestones
    var characterMilestone: Int = 100
    var redWarningInterval: Int = 15
    var selectedCharacterId: String = "madara"

    init {
        // Load initial stats for today
        repoScope.launch {
            val today = getTodayDate()
            val stats = statsDao.getStatsForDate(today)
            _currentDayReelsFlow.value = stats?.totalReels ?: 0
        }
    }

    private fun getTodayDate(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    suspend fun onReelDetected(packageName: String) {
        val today = getTodayDate()
        val current = statsDao.getStatsForDate(today) ?: DailyStatsEntity(date = today)

        val newTotal = current.totalReels + 1
        val updated = current.copy(
            totalReels = newTotal,
            instagramReels = if (packageName.contains("instagram")) current.instagramReels + 1 else current.instagramReels,
            youtubeShorts = if (packageName.contains("youtube")) current.youtubeShorts + 1 else current.youtubeShorts,
            facebookReels = if (packageName.contains("facebook")) current.facebookReels + 1 else current.facebookReels
        )

        statsDao.insertOrUpdate(updated)
        _currentDayReelsFlow.value = newTotal

        // Trigger character popup when milestone reached
        if (newTotal > 0 && newTotal % characterMilestone == 0) {
            triggerCharacterPopup(selectedCharacterId)
        } else if (newTotal > 0 && newTotal % redWarningInterval == 0) {
            // Trigger red glitch warning at configured interval
            triggerRedWarning()
        }
    }

    fun updateFeedPresence(inFeed: Boolean, packageName: String) {
        _isFeedActiveFlow.value = inFeed
    }

    private fun triggerCharacterPopup(characterId: String) {
        try {
            val intent = Intent(context, CharacterPopupService::class.java).apply {
                putExtra(CharacterPopupService.EXTRA_CHARACTER_ID, characterId)
            }
            context.startService(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun triggerRedWarning() {
        try {
            val intent = Intent(context, RedWarningService::class.java)
            context.startService(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getAllStats(): Flow<List<DailyStatsEntity>> = statsDao.getAllStats()
}
