package com.awaken.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.awaken.app.data.local.AwakenDatabase
import com.awaken.app.data.repository.AwakenRepository
import com.google.firebase.FirebaseApp

class AwakenApplication : Application() {

    lateinit var database: AwakenDatabase
        private set

    lateinit var repository: AwakenRepository
        private set

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        CrashReporter.install(base)
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        try {
            FirebaseApp.initializeApp(this)
        } catch (e: Exception) {
            // Handled when google-services.json is pending
        }

        database = AwakenDatabase.getDatabase(this)
        repository = AwakenRepository(database, this)

        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val trackingChannel = NotificationChannel(
                CHANNEL_TRACKING_ID,
                "AWAKEN Active Tracking",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live status of reel tracking and floating counter"
            }

            val milestoneChannel = NotificationChannel(
                CHANNEL_MILESTONES_ID,
                "Milestones & Interruption Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifies when conscious scrolling thresholds are reached"
                enableVibration(true)
            }

            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(trackingChannel)
            manager.createNotificationChannel(milestoneChannel)
        }
    }

    companion object {
        lateinit var instance: AwakenApplication
            private set
        const val CHANNEL_TRACKING_ID = "awaken_tracking_channel"
        const val CHANNEL_MILESTONES_ID = "awaken_milestone_channel"
    }
}
