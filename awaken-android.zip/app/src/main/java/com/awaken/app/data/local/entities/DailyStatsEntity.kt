package com.awaken.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_stats")
data class DailyStatsEntity(
    @PrimaryKey val date: String, // YYYY-MM-DD
    val totalReels: Int = 0,
    val warningCount: Int = 0,
    val questionCount: Int = 0,
    val characterCount: Int = 0,
    val focusMinutes: Int = 0,
    val instagramReels: Int = 0,
    val youtubeShorts: Int = 0,
    val facebookReels: Int = 0
)
