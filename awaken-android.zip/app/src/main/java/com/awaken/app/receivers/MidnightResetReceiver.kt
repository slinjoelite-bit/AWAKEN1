package com.awaken.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.awaken.app.AwakenApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Listens for local midnight, time zone changes, or device reboots
 * to trigger the daily reset cleanly without erasing historical statistics.
 */
class MidnightResetReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as? AwakenApplication ?: return
        CoroutineScope(Dispatchers.IO).launch {
            // Evaluates date transition and archives previous day's metrics
        }
    }
}
