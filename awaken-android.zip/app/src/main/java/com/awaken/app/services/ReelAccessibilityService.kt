package com.awaken.app.services

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.awaken.app.AwakenApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Dedicated Android AccessibilityService for AWAKEN.
 * Detects transitions in short-video feeds (Instagram Reels, YouTube Shorts, Facebook Reels)
 * with strict debounce and structural signature filtering.
 */
class ReelAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var lastTransitionTime: Long = 0
    private var lastNodeSignature: String = ""
    private var currentPackage: String = ""

    companion object {
        var isServiceRunning = false
            private set
        private const val MIN_SCROLL_DELTA_MS = 750L // Minimum time between reel swipes
        const val PKG_INSTAGRAM = "com.instagram.android"
        const val PKG_YOUTUBE = "com.google.android.youtube"
        const val PKG_FACEBOOK = "com.facebook.katana"
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val pkgName = event.packageName?.toString() ?: return
        currentPackage = pkgName

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                handleWindowStateChanged(event, pkgName)
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                handleViewScrolled(event, pkgName)
            }
        }
    }

    private fun handleWindowStateChanged(event: AccessibilityEvent, pkgName: String) {
        val className = event.className?.toString() ?: ""
        val isInReelsView = isReelsFeedActive(pkgName, className)

        val repository = (application as AwakenApplication).repository
        serviceScope.launch {
            repository.updateFeedPresence(isInReelsView, pkgName)
        }
    }

    private fun handleViewScrolled(event: AccessibilityEvent, pkgName: String) {
        val now = System.currentTimeMillis()
        if (now - lastTransitionTime < MIN_SCROLL_DELTA_MS) {
            // Rapid micro-scroll or debounce rejection
            return
        }

        val rootNode = rootInActiveWindow ?: return
        try {
            val signature = extractVideoNodeSignature(rootNode, pkgName)
            if (signature.isEmpty() || signature == lastNodeSignature) {
                // Duplicate view or unchanged video item
                return
            }

            // Valid reel transition identified!
            lastTransitionTime = now
            lastNodeSignature = signature

            val repository = (application as AwakenApplication).repository
            serviceScope.launch {
                repository.onReelDetected(pkgName)
            }
        } finally {
            rootNode.recycle()
        }
    }

    /**
     * Inspects target-specific view signatures without accessing sensitive user text
     */
    private fun extractVideoNodeSignature(root: AccessibilityNodeInfo, pkg: String): String {
        return when (pkg) {
            PKG_INSTAGRAM -> {
                val nodes = root.findAccessibilityNodeInfosByViewId("com.instagram.android:id/reel_viewer_media_container")
                if (nodes.isNotEmpty()) {
                    val target = nodes[0]
                    val hash = target.hashCode().toString()
                    target.recycle()
                    "ig_$hash"
                } else ""
            }
            PKG_YOUTUBE -> {
                val nodes = root.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/reel_player_view")
                if (nodes.isNotEmpty()) {
                    val target = nodes[0]
                    val hash = target.hashCode().toString()
                    target.recycle()
                    "yt_$hash"
                } else ""
            }
            PKG_FACEBOOK -> {
                val nodes = root.findAccessibilityNodeInfosByViewId("com.facebook.katana:id/reels_viewer")
                if (nodes.isNotEmpty()) {
                    val target = nodes[0]
                    val hash = target.hashCode().toString()
                    target.recycle()
                    "fb_$hash"
                } else ""
            }
            else -> ""
        }
    }

    private fun isReelsFeedActive(pkg: String, className: String): Boolean {
        return when (pkg) {
            PKG_INSTAGRAM -> className.contains("Reel", ignoreCase = true) || className.contains("Clips", ignoreCase = true)
            PKG_YOUTUBE -> className.contains("ReelPlayer", ignoreCase = true) || className.contains("Shorts", ignoreCase = true)
            PKG_FACEBOOK -> className.contains("ReelsViewer", ignoreCase = true)
            else -> false
        }
    }

    override fun onInterrupt() {
        // Accessibility service interrupted by system
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
    }
}
