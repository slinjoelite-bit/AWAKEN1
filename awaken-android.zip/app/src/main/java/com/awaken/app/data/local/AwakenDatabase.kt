package com.awaken.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.awaken.app.data.local.dao.*
import com.awaken.app.data.local.entities.*

@Database(
    entities = [
        UserProfileEntity::class,
        DailyStatsEntity::class,
        QuestionResponseEntity::class,
        CharacterConfigEntity::class,
        AchievementEntity::class,
        FocusSessionEntity::class,
        DailyReflectionEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AwakenDatabase : RoomDatabase() {

    abstract fun userProfileDao(): UserProfileDao
    abstract fun dailyStatsDao(): DailyStatsDao
    abstract fun questionResponseDao(): QuestionResponseDao
    abstract fun characterDao(): CharacterConfigDao
    abstract fun achievementDao(): AchievementDao
    abstract fun focusDao(): FocusSessionDao
    abstract fun reflectionDao(): DailyReflectionDao

    companion object {
        @Volatile
        private var INSTANCE: AwakenDatabase? = null

        fun getDatabase(context: Context): AwakenDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AwakenDatabase::class.java,
                    "awaken_room_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
