package com.awaken.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val icon: String,
    val progress: Int,
    val maxProgress: Int,
    val unlockedAt: Long? = null
)

@Entity(tableName = "focus_sessions")
data class FocusSessionEntity(
    @PrimaryKey val id: String,
    val activity: String,
    val durationMinutes: Int,
    val completedAt: Long = System.currentTimeMillis(),
    val wasCompleted: Boolean = true
)

@Entity(tableName = "daily_reflections")
data class DailyReflectionEntity(
    @PrimaryKey val id: String,
    val date: String,
    val moodFeeling: String,
    val accomplishedIntent: String,
    val tomorrowImprovement: String,
    val timestamp: Long = System.currentTimeMillis()
)
