package com.awaken.app.services

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.awaken.app.AwakenApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * AWAKEN Floating Reel Counter Overlay Service
 * Inspired by BrainPal's evolving facial expression:
 * - Happy face (initial low count)
 * - Gradually becomes tired and sad (as scrolling increases)
 * - Gradually becomes a mischievous/evil smile (at high counts / loop trap)
 * Underneath the face: ONLY the number of reels watched.
 *
 * Appears automatically when entering a supported short-video feed.
 * Automatically disappears a few seconds after leaving the feed.
 * Non-dismissible by tapping; no X or reset buttons.
 */
class FloatingOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val hideHandler = Handler(Looper.getMainLooper())
    private var isCurrentlyVisible = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        setupOverlayView()
        observeFeedAndReelCount()
    }

    private fun startAsForeground() {
        try {
            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                android.app.Notification.Builder(this, AwakenApplication.CHANNEL_TRACKING_ID)
            } else {
                @Suppress("DEPRECATION")
                android.app.Notification.Builder(this)
            }
            val notification = builder
                .setContentTitle("AWAKEN is active")
                .setContentText("Counting reels so you can stay conscious")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(
                    1001,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(1001, notification)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupOverlayView() {
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or // Not dismissible by tapping
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 36
            y = 160
        }

        val composeView = ComposeView(this).apply {
            setContent {
                val repository = (application as AwakenApplication).repository
                val reelCount by repository.currentDayReelsFlow.collectAsState(initial = 0)
                val dailyGoal by repository.dailyGoalFlow.collectAsState(initial = 50)

                BrainPalExpressiveCounter(count = reelCount, goal = dailyGoal)
            }
        }

        composeView.visibility = View.GONE
        overlayView = composeView

        try {
            OverlayLifecycleOwner().attachTo(composeView)
            windowManager?.addView(overlayView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun observeFeedAndReelCount() {
        val repository = (application as AwakenApplication).repository

        serviceScope.launch {
            repository.isFeedActiveFlow.collectLatest { inFeed ->
                hideHandler.removeCallbacksAndMessages(null)
                if (inFeed) {
                    showOverlay()
                } else {
                    // Gracefully disappear 3.5 seconds after leaving the supported feed
                    hideHandler.postDelayed({
                        hideOverlay()
                    }, 3500)
                }
            }
        }
    }

    private fun showOverlay() {
        overlayView?.visibility = View.VISIBLE
        isCurrentlyVisible = true
    }

    private fun hideOverlay() {
        overlayView?.visibility = View.GONE
        isCurrentlyVisible = false
    }

    override fun onDestroy() {
        super.onDestroy()
        hideHandler.removeCallbacksAndMessages(null)
        serviceScope.cancel()
        overlayView?.let { windowManager?.removeView(it) }
    }
}

/**
 * Composable BrainPal Expressive Face Counter
 * Stage 1: Happy face (0 - 45% of goal)
 * Stage 2: Tired / Sad drooping face (45% - 90% of goal)
 * Stage 3: Mischievous / Evil sinister smile (90%+ of goal)
 * Underneath: ONLY the reel number.
 */
@Composable
fun BrainPalExpressiveCounter(count: Int, goal: Int) {
    val ratio = count.toFloat() / goal.coerceAtLeast(10).toFloat()

    val isHappy = ratio < 0.45f
    val isTired = ratio in 0.45f..0.9f
    val isEvil = ratio > 0.9f

    Box(
        modifier = Modifier
            .background(Color(0xE60A0A0A), RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Animated Expressive Face Canvas
            Canvas(modifier = Modifier.size(38.dp)) {
                val center = Offset(size.width / 2, size.height / 2)
                val radius = size.minDimension / 2.2f

                when {
                    isHappy -> {
                        // Golden Yellow Friendly Base
                        drawCircle(color = Color(0xFFEAB308), radius = radius, center = center)

                        // Happy Arched Eyes
                        drawArc(
                            color = Color(0xFF451A03),
                            startAngle = 190f,
                            sweepAngle = 160f,
                            useCenter = false,
                            topLeft = Offset(center.x - 14.dp.toPx(), center.y - 8.dp.toPx()),
                            size = Size(8.dp.toPx(), 6.dp.toPx()),
                            style = Stroke(width = 2.5f)
                        )
                        drawArc(
                            color = Color(0xFF451A03),
                            startAngle = 190f,
                            sweepAngle = 160f,
                            useCenter = false,
                            topLeft = Offset(center.x + 6.dp.toPx(), center.y - 8.dp.toPx()),
                            size = Size(8.dp.toPx(), 6.dp.toPx()),
                            style = Stroke(width = 2.5f)
                        )

                        // Upward Smiling Mouth
                        drawArc(
                            color = Color(0xFF451A03),
                            startAngle = 20f,
                            sweepAngle = 140f,
                            useCenter = false,
                            topLeft = Offset(center.x - 9.dp.toPx(), center.y + 1.dp.toPx()),
                            size = Size(18.dp.toPx(), 10.dp.toPx()),
                            style = Stroke(width = 2.5f)
                        )
                    }

                    isTired -> {
                        // Desaturated Slate/Grey Weary Base
                        drawCircle(color = Color(0xFF94A3B8), radius = radius, center = center)

                        // Drooping Eyelids
                        drawCircle(color = Color(0xFF1E293B), radius = 2.5.dp.toPx(), center = Offset(center.x - 8.dp.toPx(), center.y - 2.dp.toPx()))
                        drawCircle(color = Color(0xFF1E293B), radius = 2.5.dp.toPx(), center = Offset(center.x + 8.dp.toPx(), center.y - 2.dp.toPx()))

                        // Sad Downward Mouth
                        drawArc(
                            color = Color(0xFF1E293B),
                            startAngle = 200f,
                            sweepAngle = 140f,
                            useCenter = false,
                            topLeft = Offset(center.x - 8.dp.toPx(), center.y + 7.dp.toPx()),
                            size = Size(16.dp.toPx(), 8.dp.toPx()),
                            style = Stroke(width = 2.5f)
                        )
                    }

                    else -> {
                        // Evil Crimson Horned Base
                        drawCircle(color = Color(0xFFEF4444), radius = radius, center = center)

                        // Sinister Angular Eyes
                        drawLine(
                            color = Color(0xFF450A0A),
                            start = Offset(center.x - 12.dp.toPx(), center.y - 6.dp.toPx()),
                            end = Offset(center.x - 4.dp.toPx(), center.y - 2.dp.toPx()),
                            strokeWidth = 3f
                        )
                        drawLine(
                            color = Color(0xFF450A0A),
                            start = Offset(center.x + 12.dp.toPx(), center.y - 6.dp.toPx()),
                            end = Offset(center.x + 4.dp.toPx(), center.y - 2.dp.toPx()),
                            strokeWidth = 3f
                        )

                        // Wide Mischievous Grin
                        val mouthPath = Path().apply {
                            moveTo(center.x - 10.dp.toPx(), center.y + 5.dp.toPx())
                            quadraticBezierTo(center.x, center.y + 14.dp.toPx(), center.x + 10.dp.toPx(), center.y + 5.dp.toPx())
                            close()
                        }
                        drawPath(path = mouthPath, color = Color(0xFF450A0A))
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // ONLY the number of reels watched underneath the face
            Text(
                text = count.toString(),
                color = when {
                    isEvil -> Color(0xFFF87171)
                    isTired -> Color(0xFFE2E8F0)
                    else -> Color(0xFFFDE047)
                },
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
