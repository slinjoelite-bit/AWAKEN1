package com.awaken.app.ui.permissions

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.core.app.NotificationManagerCompat
import com.awaken.app.services.ReelAccessibilityService

enum class PermissionStatus {
    GRANTED,
    PENDING,
    DENIED
}

/**
 * AWAKEN Device Permission Verification and Intent Dispatcher.
 * Evaluates real device-level permissions and distinguishes PENDING vs DENIED states
 * across activity lifecycle resumes:
 * 1. Overlay Permission (SYSTEM_ALERT_WINDOW)
 * 2. Accessibility Service (BIND_ACCESSIBILITY_SERVICE)
 * 3. Notifications (POST_NOTIFICATIONS)
 * 4. Battery Optimization Exemption (REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
 */
object PermissionsManager {

    private const val PREFS_NAME = "awaken_permission_prefs"
    const val KEY_OVERLAY = "req_overlay"
    const val KEY_ACCESSIBILITY = "req_accessibility"
    const val KEY_NOTIFICATIONS = "req_notifications"
    const val KEY_BATTERY = "req_battery"

    fun markRequested(context: Context, key: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(key, true)
            .apply()
    }

    private fun wasRequested(context: Context, key: String): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(key, false)
    }

    fun isOverlayPermissionGranted(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    fun isAccessibilityPermissionGranted(context: Context): Boolean {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        val expectedServiceName = "${context.packageName}/${ReelAccessibilityService::class.java.name}"
        return enabledServices.any {
            it.id.equals(expectedServiceName, ignoreCase = true) ||
                it.id.contains("ReelAccessibilityService")
        }
    }

    fun isNotificationPermissionGranted(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            NotificationManagerCompat.from(context).areNotificationsEnabled()
        } else {
            true
        }
    }

    fun isBatteryOptimizationIgnored(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: true
        } else {
            true
        }
    }

    fun getOverlayStatus(context: Context): PermissionStatus =
        when {
            isOverlayPermissionGranted(context) -> PermissionStatus.GRANTED
            wasRequested(context, KEY_OVERLAY) -> PermissionStatus.DENIED
            else -> PermissionStatus.PENDING
        }

    fun getAccessibilityStatus(context: Context): PermissionStatus =
        when {
            isAccessibilityPermissionGranted(context) -> PermissionStatus.GRANTED
            wasRequested(context, KEY_ACCESSIBILITY) -> PermissionStatus.DENIED
            else -> PermissionStatus.PENDING
        }

    fun getNotificationStatus(context: Context): PermissionStatus =
        when {
            isNotificationPermissionGranted(context) -> PermissionStatus.GRANTED
            wasRequested(context, KEY_NOTIFICATIONS) -> PermissionStatus.DENIED
            else -> PermissionStatus.PENDING
        }

    fun getBatteryStatus(context: Context): PermissionStatus =
        when {
            isBatteryOptimizationIgnored(context) -> PermissionStatus.GRANTED
            wasRequested(context, KEY_BATTERY) -> PermissionStatus.DENIED
            else -> PermissionStatus.PENDING
        }

    fun areRequiredCorePermissionsGranted(context: Context): Boolean {
        return isOverlayPermissionGranted(context) && isAccessibilityPermissionGranted(context)
    }

    fun requestOverlayPermission(context: Context) {
        markRequested(context, KEY_OVERLAY)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                openAppDetailsSettings(context)
            }
        }
    }

    fun requestAccessibilityPermission(context: Context) {
        markRequested(context, KEY_ACCESSIBILITY)
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            openAppDetailsSettings(context)
        }
    }

    fun requestBatteryOptimizationExemption(context: Context) {
        markRequested(context, KEY_BATTERY)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                openAppDetailsSettings(context)
            }
        }
    }

    fun openAppDetailsSettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${context.packageName}")
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
