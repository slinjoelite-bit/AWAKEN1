package com.awaken.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val userId: String,
    val name: String,
    val age: Int,
    val educationLevel: String,
    val createdAt: Long = System.currentTimeMillis()
)
