package com.awaken.app.services

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.awaken.app.R

/**
 * AWAKEN Dramatic Character Popup Service
 * Rises smoothly from the bottom screen edge with subtle ominous tremor.
 * Plays the authentic character MP3 audio track from the start.
 * Displayed as a clean isolated cutout without dialogue cards, buttons, or close icons.
 * Automatically dismisses when duration expires.
 */
class CharacterPopupService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var mediaPlayer: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        const val EXTRA_CHARACTER_ID = "extra_character_id"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val characterId = intent?.getStringExtra(EXTRA_CHARACTER_ID) ?: "madara"
        showCharacterPopup(characterId)
        return START_NOT_STICKY
    }

    private fun showCharacterPopup(characterId: String) {
        removeCurrentOverlay()

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val (drawableRes, rawAudioRes) = when (characterId.lowercase()) {
            "light", "lightyagami" -> Pair(R.drawable.lightyagami, R.raw.lightyagami)
            "shunsui", "kyoraku", "kyorakushunsui" -> Pair(R.drawable.kyorakushunsui, R.raw.kyorakushunsui)
            "yamamoto", "genryusai" -> Pair(R.drawable.yamamoto, R.raw.yamamoto)
            else -> Pair(R.drawable.madarauchiha, R.raw.madarauchiha)
        }

        // Start authentic character voice audio immediately
        try {
            mediaPlayer = MediaPlayer.create(this, rawAudioRes)?.apply {
                setOnCompletionListener {
                    // Audio completed; allow remaining linger then dismiss
                }
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or // Not dismissible by tapping
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        }

        val composeView = ComposeView(this).apply {
            setContent {
                CharacterRisingCutout(drawableRes = drawableRes)
            }
        }

        overlayView = composeView
        try {
            windowManager?.addView(overlayView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Auto-dismiss after 6.5 seconds
        handler.postDelayed({
            stopSelf()
        }, 6500)
    }

    private fun removeCurrentOverlay() {
        handler.removeCallbacksAndMessages(null)
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
        overlayView?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {
                // already removed
            }
            overlayView = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        removeCurrentOverlay()
    }
}

@Composable
fun CharacterRisingCutout(drawableRes: Int) {
    // Smooth upward entrance animation
    val riseAnim = remember { Animatable(300f) }

    // Subtle continuous tremor animation during appearance
    val infiniteTransition = rememberInfiniteTransition(label = "tremor")
    val shakeX by infiniteTransition.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(60, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shakeX"
    )

    LaunchedEffect(Unit) {
        riseAnim.animateTo(
            targetValue = 0f,
            animationSpec = tween(durationMillis = 1800, easing = FastOutSlowInEasing)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding(),
        contentAlignment = Alignment.BottomCenter
    ) {
        Image(
            painter = painterResource(id = drawableRes),
            contentDescription = "Awaken Character Cutout",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .graphicsLayer {
                    translationY = riseAnim.value
                    translationX = shakeX
                }
        )
    }
}
