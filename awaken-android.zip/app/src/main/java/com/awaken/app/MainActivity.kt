package com.awaken.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.awaken.app.services.FloatingOverlayService
import com.awaken.app.ui.permissions.PermissionStatus
import com.awaken.app.ui.permissions.PermissionsManager

class MainActivity : ComponentActivity() {

    private var onPermissionCheckRefresh: (() -> Unit)? = null

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        onPermissionCheckRefresh?.invoke()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFFAFAFA)
                ) {
                    MainAppContent(
                        registerRefreshCallback = { callback ->
                            onPermissionCheckRefresh = callback
                        },
                        onRequestOverlay = { PermissionsManager.requestOverlayPermission(this) },
                        onRequestAccessibility = { PermissionsManager.requestAccessibilityPermission(this) },
                        onRequestNotification = {
                            PermissionsManager.markRequested(this, PermissionsManager.KEY_NOTIFICATIONS)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        },
                        onRequestBattery = { PermissionsManager.requestBatteryOptimizationExemption(this) },
                        onOpenAppSettings = { PermissionsManager.openAppDetailsSettings(this) },
                        onStartFloatingService = {
                            val serviceIntent = Intent(this, FloatingOverlayService::class.java)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                startForegroundService(serviceIntent)
                            } else {
                                startService(serviceIntent)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun MainAppContent(
    registerRefreshCallback: (() -> Unit) -> Unit,
    onRequestOverlay: () -> Unit,
    onRequestAccessibility: () -> Unit,
    onRequestNotification: () -> Unit,
    onRequestBattery: () -> Unit,
    onOpenAppSettings: () -> Unit,
    onStartFloatingService: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var overlayStatus by remember { mutableStateOf(PermissionsManager.getOverlayStatus(context)) }
    var accessibilityStatus by remember { mutableStateOf(PermissionsManager.getAccessibilityStatus(context)) }
    var notificationStatus by remember { mutableStateOf(PermissionsManager.getNotificationStatus(context)) }
    var batteryStatus by remember { mutableStateOf(PermissionsManager.getBatteryStatus(context)) }
    var showAccessibilityDisclosure by remember { mutableStateOf(false) }
    var continueInLimitedMode by remember { mutableStateOf(false) }

    val refreshAllStatuses = remember {
        {
            overlayStatus = PermissionsManager.getOverlayStatus(context)
            accessibilityStatus = PermissionsManager.getAccessibilityStatus(context)
            notificationStatus = PermissionsManager.getNotificationStatus(context)
            batteryStatus = PermissionsManager.getBatteryStatus(context)
        }
    }

    LaunchedEffect(Unit) {
        registerRefreshCallback(refreshAllStatuses)
    }

    // Automatically re-check permission statuses whenever the user returns from System Settings
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                refreshAllStatuses()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val allCoreGranted =
        overlayStatus == PermissionStatus.GRANTED &&
        accessibilityStatus == PermissionStatus.GRANTED

    val grantedCount = listOf(overlayStatus, accessibilityStatus, notificationStatus, batteryStatus)
        .count { it == PermissionStatus.GRANTED }

    if (showAccessibilityDisclosure) {
        AlertDialog(
            onDismissRequest = { showAccessibilityDisclosure = false },
            containerColor = Color.White,
            title = {
                Text(
                    text = "Accessibility Service Disclosure",
                    color = Color(0xFF18181B),
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "AWAKEN uses the Android AccessibilityService API exclusively to detect short-video reel transitions and feed entry/exit inside Instagram, YouTube, and Facebook.",
                        color = Color(0xFF3F3F46),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Text(
                        text = "• Never reads private messages, passwords, or keystrokes.\n• Never monitors unrelated apps.\n• Android 13+: If blocked as a Restricted Setting, open App Info > ⋮ > Allow restricted settings.",
                        color = Color(0xFF52525B),
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showAccessibilityDisclosure = false
                        onRequestAccessibility()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("Accept & Open Settings", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAccessibilityDisclosure = false }) {
                    Text("Cancel", color = Color(0xFF52525B))
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "AWAKEN",
            color = Color(0xFF18181B),
            fontSize = 30.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 4.sp
        )

        Text(
            text = "BREAK THE LOOP. RECLAIM YOUR TIME.",
            color = Color(0xFFDC2626),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 2.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
        )

        if (!allCoreGranted && !continueInLimitedMode) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE4E4E7), RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Device Permissions Setup ($grantedCount/4)",
                        color = Color(0xFF18181B),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Grant Overlay Permission and Accessibility Service so AWAKEN can count reels and render the BrainPal floating counter.",
                        color = Color(0xFF52525B),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 6.dp, bottom = 16.dp)
                    )

                    PermissionRow(
                        title = "1. Overlay Permission (Required)",
                        desc = "Draws BrainPal counter & glitch breaks over video apps.",
                        status = overlayStatus,
                        onRequest = onRequestOverlay
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    PermissionRow(
                        title = "2. Accessibility Service (Required)",
                        desc = "Detects swipe transitions in Instagram, YouTube & Facebook.",
                        status = accessibilityStatus,
                        onRequest = { showAccessibilityDisclosure = true }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    PermissionRow(
                        title = "3. Notification Access",
                        desc = "Keeps the foreground counter service alive reliably.",
                        status = notificationStatus,
                        onRequest = onRequestNotification
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    PermissionRow(
                        title = "4. Unrestricted Battery",
                        desc = "Prevents OS task killers from closing AWAKEN.",
                        status = batteryStatus,
                        onRequest = onRequestBattery
                    )

                    if (accessibilityStatus == PermissionStatus.DENIED) {
                        Spacer(modifier = Modifier.height(12.dp))
                        TextButton(onClick = onOpenAppSettings) {
                            Text(
                                text = "Android 13+ Restricted Setting? Open App Info",
                                color = Color(0xFFDC2626),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = refreshAllStatuses) {
                            Text("Re-check Status", color = Color(0xFF3F3F46), fontSize = 12.sp)
                        }
                        TextButton(onClick = { continueInLimitedMode = true }) {
                            Text("Skip (Limited Mode)", color = Color(0xFF71717A), fontSize = 12.sp)
                        }
                    }
                }
            }
        } else {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (allCoreGranted) Color(0xFF22C55E) else Color(0xFFF59E0B),
                        RoundedCornerShape(24.dp)
                    )
            ) {
                Column(
                    modifier = Modifier.padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (allCoreGranted) "All Core Permissions Granted" else "Limited Mode Active",
                        color = if (allCoreGranted) Color(0xFF15803D) else Color(0xFFB45309),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = if (allCoreGranted) {
                            "BrainPal floating counter is armed and will appear automatically when you open Instagram Reels, YouTube Shorts, or Facebook Reels."
                        } else {
                            "Overlay or Accessibility access is still pending. Grant permissions to enable automatic floating tracking."
                        },
                        color = Color(0xFF52525B),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp, bottom = 18.dp)
                    )

                    if (allCoreGranted) {
                        Button(
                            onClick = onStartFloatingService,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Start Background Tracker",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Button(
                            onClick = { continueInLimitedMode = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF18181B)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Grant Missing Permissions",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionRow(
    title: String,
    desc: String,
    status: PermissionStatus,
    onRequest: () -> Unit
) {
    val (badgeText, badgeBg, badgeFg) = when (status) {
        PermissionStatus.GRANTED -> Triple("GRANTED", Color(0xFFDCFCE7), Color(0xFF15803D))
        PermissionStatus.DENIED -> Triple("DENIED", Color(0xFFFEE2E2), Color(0xFFB91C1C))
        PermissionStatus.PENDING -> Triple("PENDING", Color(0xFFFEF3C7), Color(0xFFB45309))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF4F4F5), RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = title,
                    color = Color(0xFF18181B),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(3.dp))
            Box(
                modifier = Modifier
                    .background(badgeBg, RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = badgeText,
                    color = badgeFg,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = desc, color = Color(0xFF52525B), fontSize = 11.sp, lineHeight = 14.sp)
        }

        if (status != PermissionStatus.GRANTED) {
            Button(
                onClick = onRequest,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (status == PermissionStatus.DENIED) Color(0xFFDC2626) else Color(0xFF18181B)
                ),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (status == PermissionStatus.DENIED) "Retry" else "Allow",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
